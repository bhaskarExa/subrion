# subrion-template-phantom
This template is a port of the [Phantom HTML Template](https://html5up.net/phantom), developed by [HTML5up](https://html5up.net/)

#### Plugins compatibility
This template works great with these plugins:
* Blog
* Contact us

### Installation
1. Download latest release https://github.com/intelliants/subrion-template-phantom/releases
2. Unpack contents of archive to `[root]/templates` folder
3. Rename `subrion-template-phantom-master` to `phantom`
4. Activate template in admin dashboard.

#### Or you can
```
cd [root]/templates # where root is the location of subrion core
git clone https://github.com/intelliants/subrion-template-phantom.git ./phantom
```
Voila! Just activate it in your Dashboard / Extensions / Templates